import React from "react";
import Footer from "../Footer/Footer";
import { Header } from "../Header/Header";


export const Sports=()=>
{
    return (<>
    
    <Header/>
<h1>Welcome Sports</h1>;
<Footer/>
    </>
    )
  
}

